# gazebo_hanoi
testing gazebo hanoi game

Run it with

```

roslaunch gazebo_hanoi game_hanoi.launch _sim:=true

```
